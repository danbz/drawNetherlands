# Draw test for landscape observations

## trucks on the highway

as seen from the train, Schiphol to Amsterdam Central

### dependencies

ofxCameraSaveLoad https://github.com/roymacdonald/ofxCameraSaveLoad

![screenshot](screenshot1.png)
![screenshot](screenshot2.png)


video on vimeo https://vimeo.com/338398783
