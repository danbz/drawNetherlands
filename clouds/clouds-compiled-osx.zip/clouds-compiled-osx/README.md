# Draw test for landscape observations

## clouds over oxford from the air

as seen from KLM embrayer BRS-AMS

### dependencies

ofxCameraSaveLoad https://github.com/roymacdonald/ofxCameraSaveLoad

![screenshot](screenshot.png)


