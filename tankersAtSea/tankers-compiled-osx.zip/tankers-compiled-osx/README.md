# Draw test for landscape observations
©2019 daniel buzzo. dan@buzzo.com  http://buzzo.com

## tankers lying at anchor off the Zaandvoort coast

as seen from KLM embrayer BRS-AMS

### dependencies
* C++ and openFrameworks - openframeworks.cc

* ofxCameraSaveLoad https://github.com/roymacdonald/ofxCameraSaveLoad

### key controls
* 'f' toggle full screen
* 'g' show text gui
* 'l' load saved camera position
* 's' save new camera position
* 'h' zero centre camera postion

![screenshot](tankers-screenshot.png)


